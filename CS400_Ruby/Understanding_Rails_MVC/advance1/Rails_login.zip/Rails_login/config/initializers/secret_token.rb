# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
SimpleLogin::Application.config.secret_key_base = 'cac567a715d2e1d48d18165105d2c5cae9e30cb574d8a2b9dd6f7752c92aca5d5193f48563dc190e15b519709124ad1d2d0b651564672a5098454ac6f07738fc'
