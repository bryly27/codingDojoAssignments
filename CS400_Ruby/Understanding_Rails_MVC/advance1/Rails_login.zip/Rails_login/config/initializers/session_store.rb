# Be sure to restart your server when you modify this file.

SimpleLogin::Application.config.session_store :cookie_store, key: '_simple_login_session'
