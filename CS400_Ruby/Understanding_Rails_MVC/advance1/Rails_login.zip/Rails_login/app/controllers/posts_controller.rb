class PostsController < ApplicationController
  def index

  end

  def create
  	@posts = Post.new(comment_params)
  	@posts.save
  	redirect_to '/messages/index'
  end	

  private

  	def comment_params
  		params.require(:post).permit(:post, :user_id, :message_id)
  	end
end
