class MessagesController < ApplicationController
  def index
  	@messages = Message.select("messages.id blah, users.first_name, users.last_name, messages.message, messages.created_at").joins(:user).order(blah: :asc)
  	# @messages = nil
  	@posts = Post.select("users.first_name, users.last_name, posts.post, posts.created_at, posts.message_id").joins(:user)
  end

  def create
  	@messages = Message.new(message_params)
  	@messages.save
  	redirect_to '/messages/index'
  end	

  private

  	def message_params
  		params.require(:message).permit(:message, :user_id)
  	end

end
