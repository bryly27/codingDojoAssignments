<html>
<head>
	<title></title>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</head>
<script type="text/javascript">
	$(document).ready(function(){	
		$("#submit").on('keyup', function(){
			$.post(
				$("#submit").attr('action'),
				$("#submit").serialize(),
				function(output){
					// alert('hi');
					// console.log(output);
				// $.each(output, function(index, val) {
    //         $('<td>' + index + '</td>').appendTo($('#table'));
    //     });
			for(var i=0; i<output.length; i++)
			{
				// console.log(output[i]['first_name']);

				$('#table').append('<tr><td>' + output[i]['email'] + '</td><td>' + output[i]['first_name'] + '</td><td>'+ output[i]['last_name'] + '</td></tr>');
			}
				},"json"
			);
			return false;
		});
	});
</script>
<style type="text/css">

table {
	border: 1px solid black;
	border-collapse: collapse;
}

td, th {
	border: 1px solid black;
}

</style>
<body>
	<form id='submit' action='/email/process' method='post'>
		<p>Email: <input type='text' name='email'></p>
		<!-- <input type='submit' name='submit'> -->
		<!-- <input type='hidden' name='action' value='submit'> -->
	</form>

	<table>
		<thead>
			<tr>
				<th>Email</th>
				<th>First Name</th>
				<th>Last Name</th>
			</tr>
		</thead>
		<tbody id='table'>
	

		</tbody>
	</table>
</body>
</html>