// this is our server.js file

// require express so that we can build an express app
var express = require('express');
// require http so we can use http request and response stuff
var http = require('http');
// require path so we can use path stuff like path.join
var path = require('path');


// create the express app
// express is a set of tools that allows us to more easily deal with http actions and some other stuff involving setting variables and getting them
var app = express();

// so that we can parse post data through the req.body
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded());
app.use(bodyParser.json());

// allows us to use put, patch, and delete http verbs
var methodOverride = require('method-override');
app.use(methodOverride('X-HTTP-Method-Override'));

// sets up a static file server that points to the client directory
app.use(express.static(path.join(__dirname, 'client')));

app.set('views', path.join(__dirname, './client/views'));
app.set('static', path.join(__dirname, './client/static'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');


var mongoose = require('./config/mongoose.js');

var routes = require('./config/routes.js')(app);

// sets the port
app.set('port', 3000);

// starts listening
var server = app.listen(app.get('port'), function() {
	console.log('cool stuff on: '+ app.get('port'));
})

//=======================================
var io = require('socket.io').listen(server);
io.sockets.on('connection', function(socket){
var users = [];
var chatbox = [];

	console.log('using socket');

chatting();
function chatting(){
	var name = '';

	socket.on('new_name', function(data){
		name = data;
		users.push(name);
		chatbox.push({ new_user: data + ' has signed on' });
		socket.emit('show_chatbox', chatbox);
		io.emit('update_chatbox', chatbox);
		io.emit('display_users', users);
	});

	socket.on('add_message', function(data){
		chatbox.push(data);
		io.emit('update_chatbox', chatbox);
	});

	socket.on('image', function(data){
		chatbox.push({photo: data});
		io.emit('update_chatbox', chatbox);
	});


 	socket.on('disconnect', function(){
		chatbox.push({disconnecting: name + ' has disconnected'});
		io.emit('update_chatbox', chatbox);

		var temp = 0;
		for(var i=0; i<users.length; i++){
			if(users[i] == name){
				temp = users[i];
				users[i] = users[users.length-1];
				users[users.length-1] = temp;
				users.pop();
				if(users.length == 0){
					chatbox = [];
					console.log(chatbox);
				}
			}
		}
		io.emit('display_users', users);
	});
 }
})

