$(document).ready(function(){
	 		var socket = io.connect();
	 		console.log(socket);
	 		$('#chatbox').hide();

	 		console.log('djfklajsdlfas');

	 		do{
	 			var name = prompt('Please enter your name:');
	 		} while (name.length <2);

	 		socket.emit('new_name', name)

	 		socket.on('show_chatbox', function(data){
	 			$('#chatbox').fadeIn();
	 			console.log('fading in');
	 		});

	 		socket.on('update_chatbox', function(data){
	 			console.log(data);
	 			$('#chat').html('');
	 			for(var i=0; i<data.length; i++){
	 				if(data[i].new_user){
	 					$('#chat').append("<p class='new_user'>"+data[i].new_user +"</p>");
	 				} else if(data[i].name && data[i].name == name){
	 					$('#chat').append("<p class='user'>"+data[i].name + ': ' + data[i].message + "</p>");
	 				} else if(data[i].name){
	 					$('#chat').append("<p>"+data[i].name + ': ' + data[i].message + "</p>");
	 				} else if(data[i].photo){
	 					$('#chat').append("<img class='message_photo' src="+data[i].photo+"></br>");
	 				} else {
	 					$('#chat').append("<p class='disconnecting'>"+data[i].disconnecting+"</p>");
	 				}
	 			}
	 				$('#chat').scrollTop(10000);
	 		});

	 		socket.on('display_users', function(data){
	 			$('#user').html('');
	 			for(var i=0; i<data.length; i++){
	 				$('#user').append("<p>" + data[i] + "</p>");
	 			}
	 		});

	 		$('#submit').click(function(){
	 			console.log('clicking the submit button');
	 			event.preventDefault();
	 			socket.emit('add_message', {name: name, message: $('#message').val()});
	 			$('form')[0].reset();
	 		});

	 		$('#photo').on('change', function(e){
	 			var file = e.originalEvent.target.files[0],
	 					reader = new FileReader();
	 				reader.onload = function(evt){
	 					socket.emit('image', evt.target.result);
	 				};
	 				reader.readAsDataURL(file);
	 		})

	 	});