// create the controller and we're telling it that we are going to use $scope and we are going to use a FriendFactory and that it belongs to the fullMeanDemo app
sample_mean_stack.controller('users_controller', function($window, $scope, $rootScope, $location, $routeParams, users_factory, topics_factory) {
	// update_topics();
	console.log("loaded the controller");
	console.log($window.sessionStorage['users']);

	$rootScope.user = $window.sessionStorage['user'];

	$scope.login = function(data){
		$location.path('/dashboard');
		$window.sessionStorage['user'] = data;
		console.log(data);
	}

	// $scope.add_topic = function(data){

	// }

	// $scope.add_user = function(data) {
	// 	data.topic_count = 0;
	// 	data.post_count = 0;
	// 	data.comment_count = 0;
	// 	var info = data;
	// 	users_factory.add_user(data, function(data) {
	// 		get_user(info);
	// 	});	
	// };

	// function get_user(data){
	// 	users_factory.get_user(data, function(output){
	// 		console.log(output[0]);
	// 		$location.path('/dashboard/'+output[0].username);
	// 		// $rootScope.users = output;
	// 		get_profile();
	// 	})
	// };

	// function get_profile(){
	// users_factory.get_profile($routeParams.id, function(output){
	// 	$scope.users = output;
	// 	console.log(output[0])
	// 	});
	// };


	// $scope.add_topic = function(data){
	// 	data.topic_post_count = 0;
	// 	console.log($scope.users[0].topic_count);
	// 	data.counter = $scope.users[0].topic_count +1;
	// 	console.log(data.counter);
	// 	data.topic_username = $routeParams.id;
	// 	users_factory.add_topic(data, function(data){
	// 		$scope.topic = {};
	// 		update_topics();
	// 		users_factory.get_profile($routeParams.id, function(output){
	// 			$scope.users = output;
	// 			console.log(output[0])
	// 			});
	// 	});
	// };


	// function update_topics(){
	// 	users_factory.update_topics(function(output){
	// 		$scope.topics = output;
	// 	})
	// }


	// topics_factory.get_topic($routeParams.id, function(output){
	// 	$scope.topics = output;
	// 	console.log(output);
	// })


})


