$(document).ready(function(){
  alert('35 x 2 = 70');
});