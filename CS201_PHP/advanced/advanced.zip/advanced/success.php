<?php
	session_start();

?>

<html>
<head>
	<title>Validation Success</title>
</head>
<body>
	<h1>You successfully submitted your data</h1>

</body>
</html>