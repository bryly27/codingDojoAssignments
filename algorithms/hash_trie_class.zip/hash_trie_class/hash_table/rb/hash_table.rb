require_relative '../../tries/rb/trie'

class HashTable
  def initialize
    @table = Array.new(26)
  end

  def build_links
    @table.length.times { |i| @table[i] = [] }
  end

  def link_built?
    @table[0].class == Array
  end

  def simple_hash(data)
    data.ord - 65
  end

  def better_hash(data)
    data.split("").map { |k, v| data[k].ord }.reduce(:+) % 26
  end

  def simple_put(data)
    @table[simple_hash(data)] = data
  end

  def link_put(data)
    build_links unless link_built?
    loc = better_hash(data)
    @table[loc] ? @table[loc] << data : @table[loc] = data
  end

  def show_distribution
    @table.length.times { |i| puts "#{i}: #{@table[i]}" }
  end

  def build_trie
    alphabet = ('A'..'Z').to_a
    alphabet.each_with_index do |value, index|
      @table[index] = Trie.new(value)
    end
  end

  def trie_built?
    @table[0].class == Trie
  end

  def trie_put(data, value)
    build_trie unless trie_built?
    location = simple_hash(data)
    word = @table[location]
    word.insert(data, value)
  end

  def trie_get(data)
    location = simple_hash(data)
    # find the location
    word = @table[location]
    # find the right trie
    puts word.get(data)
    # call get on that trie
  end
end
